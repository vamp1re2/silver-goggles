package com.righty.akxiiai.ui.theme

import androidx.compose.ui.graphics.Color

// ChatGPT-like colors
val ChatGPTGreen = Color(0xFF10A37F)
val ChatGPTGreenLight = Color(0xFF1BC5A0)
val ChatGPTGreenDark = Color(0xFF0D8A6B)

// Gemini-like colors
val GeminiBlue = Color(0xFF4285F4)
val GeminiBlueLight = Color(0xFF5A95F5)
val GeminiBlueDark = Color(0xFF1A73E8)

// Chat bubble colors
val UserBubbleLight = Color(0xFFE3F2FD)
val UserBubbleDark = Color(0xFF1E3A8A)
val AIBubbleLight = Color(0xFFF5F5F5)
val AIBubbleDark = Color(0xFF2D2D2D)

// Background colors
val ChatBackgroundLight = Color(0xFFFFFFFF)
val ChatBackgroundDark = Color(0xFF0F0F0F)

// Text colors
val TextPrimaryLight = Color(0xFF1A1A1A)
val TextPrimaryDark = Color(0xFFE5E5E5)
val TextSecondaryLight = Color(0xFF666666)
val TextSecondaryDark = Color(0xFF999999)

// Legacy colors for compatibility
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)