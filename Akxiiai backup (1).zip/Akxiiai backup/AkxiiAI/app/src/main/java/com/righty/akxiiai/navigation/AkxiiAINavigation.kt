package com.righty.akxiiai.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.righty.akxiiai.ui.screens.ChatScreen
import com.righty.akxiiai.ui.screens.MenuScreen
import com.righty.akxiiai.ui.screens.SettingsScreen
import com.righty.akxiiai.ui.screens.TrainingScreen

@Composable
fun AkxiiAINavigation(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = "chat"
    ) {
        composable("chat") {
            ChatScreen(
                onNavigateToSettings = {
                    navController.navigate("settings")
                },
                onNavigateToMenu = {
                    navController.navigate("menu")
                }
            )
        }
        
        composable("menu") {
            MenuScreen(
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToChat = {
                    navController.navigate("chat") {
                        popUpTo("chat") { inclusive = true }
                    }
                },
                onNavigateToTraining = {
                    navController.navigate("training")
                },
                onNavigateToSettings = {
                    navController.navigate("settings")
                }
            )
        }
        
        composable("settings") {
            SettingsScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
        
        composable("training") {
            TrainingScreen(
                onNavigateBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
