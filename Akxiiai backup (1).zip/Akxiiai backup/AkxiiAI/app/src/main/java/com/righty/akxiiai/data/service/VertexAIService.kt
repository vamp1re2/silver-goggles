package com.righty.akxiiai.data.service

import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.righty.akxiiai.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.time.LocalDateTime
import java.util.UUID

class VertexAIService {
    
    private val client = OkHttpClient()
    private val gson = Gson()
    
    // Vertex AI API configuration
    private val apiKey = "AQ.Ab8RN6LdXL6eAtW5hxRJanHs9X2Z6GMiWyUaQ5HVb1tV-dJR8Q"
    private val baseUrl = "https://us-central1-aiplatform.googleapis.com/v1"
    private val projectId = "akxii-ai-project" // You'll need to set this up in Google Cloud
    private val location = "us-central1"
    private val model = "gemini-1.5-pro"
    
    suspend fun sendMessage(
        messages: List<ChatMessage>,
        userPreferences: UserPreferences,
        customInstructions: String = ""
    ): Result<ChatMessage> = withContext(Dispatchers.IO) {
        try {
            val vertexMessages = convertToVertexMessages(messages, userPreferences, customInstructions)
            val request = createVertexRequest(vertexMessages, userPreferences.isNsfwMode)
            
            val response = client.newCall(request).execute()
            
            if (response.isSuccessful) {
                val responseBody = response.body?.string()
                val vertexResponse = gson.fromJson(responseBody, VertexAIResponse::class.java)
                
                val aiMessage = ChatMessage(
                    id = UUID.randomUUID().toString(),
                    content = vertexResponse.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Sorry, I couldn't generate a response.",
                    isUser = false,
                    timestamp = LocalDateTime.now()
                )
                
                Result.success(aiMessage)
            } else {
                val errorMessage = ChatMessage(
                    id = UUID.randomUUID().toString(),
                    content = "Error: ${response.message}",
                    isUser = false,
                    timestamp = LocalDateTime.now(),
                    isError = true
                )
                Result.success(errorMessage)
            }
        } catch (e: Exception) {
            val errorMessage = ChatMessage(
                id = UUID.randomUUID().toString(),
                content = "Error: ${e.message}",
                isUser = false,
                timestamp = LocalDateTime.now(),
                isError = true
            )
            Result.success(errorMessage)
        }
    }
    
    private fun convertToVertexMessages(
        messages: List<ChatMessage>,
        userPreferences: UserPreferences,
        customInstructions: String
    ): List<VertexAIMessage> {
        val vertexMessages = mutableListOf<VertexAIMessage>()
        
        // Add system message with personality and instructions
        val systemMessage = buildSystemMessage(userPreferences, customInstructions)
        vertexMessages.add(VertexAIMessage("system", systemMessage))
        
        // Convert chat messages
        messages.forEach { message ->
            vertexMessages.add(
                VertexAIMessage(
                    role = if (message.isUser) "user" else "assistant",
                    content = message.content
                )
            )
        }
        
        return vertexMessages
    }
    
    private fun buildSystemMessage(
        userPreferences: UserPreferences,
        customInstructions: String
    ): String {
        val basePersonality = when (userPreferences.aiPersonality) {
            "helpful" -> "You are a helpful, harmless, and honest AI assistant."
            "creative" -> "You are a creative and imaginative AI assistant who loves to explore ideas and possibilities."
            "professional" -> "You are a professional and formal AI assistant focused on providing accurate information."
            "casual" -> "You are a friendly and casual AI assistant who communicates in a relaxed manner."
            else -> "You are a helpful AI assistant."
        }
        
        val nsfwNotice = if (userPreferences.isNsfwMode) {
            " The user has enabled NSFW mode, so you may discuss adult topics when appropriate."
        } else {
            " Keep all responses appropriate and family-friendly."
        }
        
        val customPart = if (customInstructions.isNotEmpty()) {
            " Additional instructions: $customInstructions"
        } else ""
        
        return basePersonality + nsfwNotice + customPart
    }
    
    private fun createVertexRequest(
        messages: List<VertexAIMessage>,
        isNsfwAllowed: Boolean
    ): Request {
        val requestBody = VertexAIRequest(
            messages = messages,
            temperature = 0.7,
            maxTokens = 1000,
            isNsfwAllowed = isNsfwAllowed
        )
        
        val json = gson.toJson(requestBody)
        val body = json.toRequestBody("application/json".toMediaType())
        
        return Request.Builder()
            .url("$baseUrl/projects/$projectId/locations/$location/publishers/google/models/$model:generateContent")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body)
            .build()
    }
    
    suspend fun trainWithExample(
        input: String,
        expectedOutput: String,
        category: String = "general"
    ): Result<TrainingExample> = withContext(Dispatchers.IO) {
        try {
            val trainingExample = TrainingExample(
                id = UUID.randomUUID().toString(),
                input = input,
                expectedOutput = expectedOutput,
                category = category,
                createdAt = LocalDateTime.now()
            )
            
            // In a real implementation, you would save this to a database
            // and use it to fine-tune the model or adjust responses
            Result.success(trainingExample)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

// Data classes for Vertex AI API
data class VertexAIRequest(
    val messages: List<VertexAIMessage>,
    val temperature: Double,
    val maxTokens: Int,
    val isNsfwAllowed: Boolean
)

data class VertexAIMessage(
    val role: String,
    val content: String
)

data class VertexAIResponse(
    val candidates: List<VertexAICandidate>,
    val usageMetadata: VertexAIUsageMetadata
)

data class VertexAICandidate(
    val content: VertexAIContent,
    val finishReason: String
)

data class VertexAIContent(
    val parts: List<VertexAIPart>
)

data class VertexAIPart(
    val text: String
)

data class VertexAIUsageMetadata(
    val promptTokenCount: Int,
    val candidatesTokenCount: Int,
    val totalTokenCount: Int
)
