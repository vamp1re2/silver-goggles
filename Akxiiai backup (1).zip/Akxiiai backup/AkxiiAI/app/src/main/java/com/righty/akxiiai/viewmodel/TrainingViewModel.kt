package com.righty.akxiiai.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.righty.akxiiai.data.model.TrainingExample
import com.righty.akxiiai.data.service.VertexAIService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.util.UUID

data class TrainingUiState(
    val trainingExamples: List<TrainingExample> = emptyList(),
    val isLoading: Boolean = false
)

class TrainingViewModel(
    private val vertexAIService: VertexAIService
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(TrainingUiState())
    val uiState: StateFlow<TrainingUiState> = _uiState.asStateFlow()
    
    // In a real app, you would load from a database
    private val trainingExamples = mutableListOf<TrainingExample>()
    
    fun addTrainingExample(input: String, expectedOutput: String, category: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            
            val result = vertexAIService.trainWithExample(input, expectedOutput, category)
            
            result.onSuccess { example ->
                trainingExamples.add(example)
                _uiState.value = _uiState.value.copy(
                    trainingExamples = trainingExamples.toList(),
                    isLoading = false
                )
            }.onFailure { error ->
                // Handle error
                _uiState.value = _uiState.value.copy(isLoading = false)
            }
        }
    }
    
    fun deleteTrainingExample(exampleId: String) {
        trainingExamples.removeAll { it.id == exampleId }
        _uiState.value = _uiState.value.copy(
            trainingExamples = trainingExamples.toList()
        )
    }
    
    fun clearAllTrainingExamples() {
        trainingExamples.clear()
        _uiState.value = _uiState.value.copy(
            trainingExamples = emptyList()
        )
    }
}
