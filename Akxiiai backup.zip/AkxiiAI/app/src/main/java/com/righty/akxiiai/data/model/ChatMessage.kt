package com.righty.akxiiai.data.model

import java.time.LocalDateTime

data class ChatMessage(
    val id: String,
    val content: String,
    val isUser: Boolean,
    val timestamp: LocalDateTime = LocalDateTime.now(),
    val isTyping: Boolean = false,
    val isError: Boolean = false
)

data class ChatSession(
    val id: String,
    val title: String,
    val messages: List<ChatMessage>,
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val lastUpdated: LocalDateTime = LocalDateTime.now()
)

data class UserPreferences(
    val isDarkTheme: Boolean = false,
    val isNsfwMode: Boolean = false,
    val aiPersonality: String = "helpful",
    val customInstructions: String = "",
    val trainingData: List<TrainingExample> = emptyList()
)

data class TrainingExample(
    val id: String,
    val input: String,
    val expectedOutput: String,
    val category: String = "general",
    val createdAt: LocalDateTime = LocalDateTime.now()
)

data class VertexAIRequest(
    val messages: List<VertexAIMessage>,
    val temperature: Double = 0.7,
    val maxTokens: Int = 1000,
    val isNsfwAllowed: Boolean = false
)

data class VertexAIMessage(
    val role: String, // "user" or "assistant"
    val content: String
)

data class VertexAIResponse(
    val candidates: List<VertexAICandidate>,
    val usageMetadata: VertexAIUsageMetadata
)

data class VertexAICandidate(
    val content: VertexAIContent,
    val finishReason: String
)

data class VertexAIContent(
    val parts: List<VertexAIPart>
)

data class VertexAIPart(
    val text: String
)

data class VertexAIUsageMetadata(
    val promptTokenCount: Int,
    val candidatesTokenCount: Int,
    val totalTokenCount: Int
)
