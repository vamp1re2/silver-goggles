package com.righty.akxiiai.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.righty.akxiiai.data.model.UserPreferences
import com.righty.akxiiai.data.repository.PreferencesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SettingsUiState(
    val isDarkTheme: Boolean = false,
    val isNsfwMode: Boolean = false,
    val aiPersonality: String = "helpful",
    val customInstructions: String = "",
    val userPreferences: UserPreferences = UserPreferences()
)

class SettingsViewModel(
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()
    
    init {
        loadUserPreferences()
    }
    
    private fun loadUserPreferences() {
        viewModelScope.launch {
            preferencesRepository.userPreferences.collect { preferences ->
                _uiState.value = _uiState.value.copy(
                    userPreferences = preferences,
                    isDarkTheme = preferences.isDarkTheme,
                    isNsfwMode = preferences.isNsfwMode,
                    aiPersonality = preferences.aiPersonality,
                    customInstructions = preferences.customInstructions
                )
            }
        }
    }
    
    fun toggleTheme() {
        viewModelScope.launch {
            val newTheme = !_uiState.value.isDarkTheme
            preferencesRepository.updateDarkTheme(newTheme)
        }
    }
    
    fun toggleNsfwMode() {
        viewModelScope.launch {
            val newNsfwMode = !_uiState.value.isNsfwMode
            preferencesRepository.updateNsfwMode(newNsfwMode)
        }
    }
    
    fun updateAiPersonality(personality: String) {
        viewModelScope.launch {
            preferencesRepository.updateAiPersonality(personality)
        }
    }
    
    fun updateCustomInstructions(instructions: String) {
        viewModelScope.launch {
            preferencesRepository.updateCustomInstructions(instructions)
        }
    }
}
