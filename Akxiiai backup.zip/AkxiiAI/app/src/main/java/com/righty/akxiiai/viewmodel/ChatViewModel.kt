package com.righty.akxiiai.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.righty.akxiiai.data.model.ChatMessage
import com.righty.akxiiai.data.model.UserPreferences
import com.righty.akxiiai.data.repository.PreferencesRepository
import com.righty.akxiiai.data.service.VertexAIService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.util.UUID

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val isDarkTheme: Boolean = false,
    val isNsfwMode: Boolean = false,
    val userPreferences: UserPreferences = UserPreferences()
)

class ChatViewModel(
    private val vertexAIService: VertexAIService,
    private val preferencesRepository: PreferencesRepository
) : ViewModel() {
    
    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()
    
    init {
        loadUserPreferences()
    }
    
    private fun loadUserPreferences() {
        viewModelScope.launch {
            preferencesRepository.userPreferences.collect { preferences ->
                _uiState.value = _uiState.value.copy(
                    userPreferences = preferences,
                    isDarkTheme = preferences.isDarkTheme,
                    isNsfwMode = preferences.isNsfwMode
                )
            }
        }
    }
    
    fun sendMessage(content: String) {
        if (content.isBlank()) return
        
        val userMessage = ChatMessage(
            id = UUID.randomUUID().toString(),
            content = content,
            isUser = true,
            timestamp = LocalDateTime.now()
        )
        
        // Add user message immediately
        _uiState.value = _uiState.value.copy(
            messages = _uiState.value.messages + userMessage,
            isLoading = true
        )
        
        // Send to AI
        viewModelScope.launch {
            val result = vertexAIService.sendMessage(
                messages = _uiState.value.messages + userMessage,
                userPreferences = _uiState.value.userPreferences
            )
            
            result.onSuccess { aiMessage ->
                _uiState.value = _uiState.value.copy(
                    messages = _uiState.value.messages + aiMessage,
                    isLoading = false
                )
            }.onFailure { error ->
                val errorMessage = ChatMessage(
                    id = UUID.randomUUID().toString(),
                    content = "Error: ${error.message}",
                    isUser = false,
                    timestamp = LocalDateTime.now(),
                    isError = true
                )
                _uiState.value = _uiState.value.copy(
                    messages = _uiState.value.messages + errorMessage,
                    isLoading = false
                )
            }
        }
    }
    
    fun clearChat() {
        _uiState.value = _uiState.value.copy(messages = emptyList())
    }
    
    fun toggleTheme() {
        viewModelScope.launch {
            val newTheme = !_uiState.value.isDarkTheme
            preferencesRepository.updateDarkTheme(newTheme)
        }
    }
    
    fun toggleNsfwMode() {
        viewModelScope.launch {
            val newNsfwMode = !_uiState.value.isNsfwMode
            preferencesRepository.updateNsfwMode(newNsfwMode)
        }
    }
    
    fun updateAiPersonality(personality: String) {
        viewModelScope.launch {
            preferencesRepository.updateAiPersonality(personality)
        }
    }
    
    fun updateCustomInstructions(instructions: String) {
        viewModelScope.launch {
            preferencesRepository.updateCustomInstructions(instructions)
        }
    }
}
