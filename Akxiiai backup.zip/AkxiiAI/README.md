# AkxiiAI - AI Chatbot App

A modern AI chatbot application built with Jetpack Compose, featuring ChatGPT and Gemini-like UI design with Vertex AI integration.

## Features

### 🤖 AI Chat Interface
- **ChatGPT/Gemini-like Design**: Modern, clean chat interface with bubble-style messages
- **Real-time Typing Indicators**: Visual feedback when AI is responding
- **Message History**: Persistent chat sessions with scrollable message history
- **Error Handling**: Graceful error handling with user-friendly error messages

### 🎨 Theme System
- **Light/Dark Themes**: Automatic system theme detection with manual toggle
- **Material 3 Design**: Modern Material Design 3 components and colors
- **Custom Color Scheme**: ChatGPT green and Gemini blue color palette
- **Responsive UI**: Adaptive layout for different screen sizes

### 🔞 Content Control
- **NSFW Mode Toggle**: Optional adult content mode for mature conversations
- **Content Filtering**: Built-in content filtering when NSFW mode is disabled
- **User Preferences**: Persistent settings storage using DataStore

### 🧠 AI Training & Customization
- **Custom AI Training**: Add training examples to personalize AI responses
- **Personality Selection**: Choose from different AI personalities (helpful, creative, professional, casual)
- **Custom Instructions**: Provide specific instructions for AI behavior
- **Training Categories**: Organize training examples by category

### 🔗 Vertex AI Integration
- **Google Vertex AI**: Powered by Google's Vertex AI platform
- **Gemini Model**: Uses Gemini 1.5 Pro model for advanced AI capabilities
- **API Key Configuration**: Secure API key management
- **Real-time Communication**: Live chat with AI responses

## Technical Architecture

### 🏗️ Architecture Components
- **MVVM Pattern**: Model-View-ViewModel architecture for clean separation
- **Jetpack Compose**: Modern declarative UI framework
- **Navigation Component**: Type-safe navigation between screens
- **DataStore**: Modern preferences storage solution
- **Retrofit**: HTTP client for API communication
- **Coroutines**: Asynchronous programming with Kotlin coroutines

### 📱 Screens
1. **Chat Screen**: Main conversation interface
2. **Settings Screen**: Theme, NSFW mode, and AI personality settings
3. **Training Screen**: AI training examples management
4. **Menu Screen**: Navigation hub for all features

### 🔧 Key Dependencies
- `androidx.compose.material3` - Material 3 components
- `androidx.navigation:navigation-compose` - Navigation
- `androidx.lifecycle:lifecycle-viewmodel-compose` - ViewModel
- `com.squareup.retrofit2:retrofit` - HTTP client
- `com.google.cloud:google-cloud-aiplatform` - Vertex AI
- `androidx.datastore:datastore-preferences` - Preferences storage

## Setup Instructions

### 1. Google Cloud Setup
1. Create a Google Cloud Project
2. Enable Vertex AI API
3. Create a service account with Vertex AI permissions
4. Generate an API key for the service account

### 2. API Configuration
Update the API key in `VertexAIService.kt`:
```kotlin
private val apiKey = "YOUR_VERTEX_AI_API_KEY"
private val projectId = "YOUR_GOOGLE_CLOUD_PROJECT_ID"
```

### 3. Build and Run
1. Open the project in Android Studio
2. Sync Gradle dependencies
3. Build and run on an Android device or emulator

## Usage

### 💬 Starting a Chat
1. Open the app to see the main chat interface
2. Type your message in the input field
3. Tap the send button or press Enter
4. Wait for the AI response

### ⚙️ Customizing Settings
1. Tap the settings icon in the chat screen
2. Toggle dark/light theme as preferred
3. Enable/disable NSFW mode for adult content
4. Select AI personality from dropdown
5. Add custom instructions for AI behavior

### 🎓 Training Your AI
1. Navigate to the training screen from the menu
2. Tap the "+" button to add training examples
3. Provide input/output examples for desired AI behavior
4. Categorize examples for better organization
5. Delete examples you no longer need

## Features in Detail

### 🎨 UI/UX Features
- **Smooth Animations**: Typing indicators and message transitions
- **Accessibility**: Screen reader support and proper content descriptions
- **Responsive Design**: Works on phones and tablets
- **Modern Icons**: Material Design icons throughout the interface

### 🔒 Privacy & Security
- **Local Storage**: All preferences stored locally on device
- **Secure API**: HTTPS communication with Vertex AI
- **No Data Collection**: No user data is collected or stored externally

### 🚀 Performance
- **Efficient Rendering**: Lazy loading for message lists
- **Memory Management**: Proper lifecycle management for ViewModels
- **Network Optimization**: Efficient API calls with proper error handling

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For issues and questions:
1. Check the GitHub issues page
2. Create a new issue with detailed description
3. Include device information and steps to reproduce

---

**Note**: This app requires a valid Google Cloud Vertex AI API key to function. Make sure to set up your Google Cloud project and obtain the necessary credentials before using the app.
