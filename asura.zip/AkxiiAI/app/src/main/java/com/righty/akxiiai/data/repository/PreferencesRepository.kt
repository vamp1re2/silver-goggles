package com.righty.akxiiai.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.righty.akxiiai.data.model.UserPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "akxii_preferences")

class PreferencesRepository(private val context: Context) {
    
    private val isDarkThemeKey = booleanPreferencesKey("is_dark_theme")
    private val isNsfwModeKey = booleanPreferencesKey("is_nsfw_mode")
    private val aiPersonalityKey = stringPreferencesKey("ai_personality")
    private val customInstructionsKey = stringPreferencesKey("custom_instructions")
    
    val userPreferences: Flow<UserPreferences> = context.dataStore.data.map { preferences ->
        UserPreferences(
            isDarkTheme = preferences[isDarkThemeKey] ?: false,
            isNsfwMode = preferences[isNsfwModeKey] ?: false,
            aiPersonality = preferences[aiPersonalityKey] ?: "helpful",
            customInstructions = preferences[customInstructionsKey] ?: ""
        )
    }
    
    suspend fun updateDarkTheme(isDark: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[isDarkThemeKey] = isDark
        }
    }
    
    suspend fun updateNsfwMode(isNsfw: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[isNsfwModeKey] = isNsfw
        }
    }
    
    suspend fun updateAiPersonality(personality: String) {
        context.dataStore.edit { preferences ->
            preferences[aiPersonalityKey] = personality
        }
    }
    
    suspend fun updateCustomInstructions(instructions: String) {
        context.dataStore.edit { preferences ->
            preferences[customInstructionsKey] = instructions
        }
    }
}
